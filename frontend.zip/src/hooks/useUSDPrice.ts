import { Currency } from "src/utils/token";



export default function useUSDPrice(currency?: Currency) {

}