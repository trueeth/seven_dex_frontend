
export interface DataContextApi {

    tokenPrices: any,
    tradeVolume: any
}