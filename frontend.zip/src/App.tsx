
import { Route, BrowserRouter, Routes } from 'react-router-dom'
import { ThemeProvider, createTheme } from '@mui/material/styles'
import ViewBase from './components/viewbase'
import { WagmiProvider, client } from './utils/wagmi'
import { Provider } from 'react-redux'
import store from './state'
import { SWRConfig } from 'swr'
import { LanguageProvider } from './context/Localization'
import { fetchStatusMiddleware } from './hooks/useSWRContract'
import { Updaters } from './Updater'
import { usePollBlockNumber } from './state/block/hooks'
import Home from 'src/views/home'
import Bridge from 'src/views/bridge'
import Docs from 'src/views/docs'
import Farm from 'src/views/farm'
import Liquidity from './views/liquidity'
import Swap from './views/swap'
import useEagerConnect from './hooks/useEagerConnect'
import { ToastListener, ToastsProvider } from './context/ToastsContext'
import { DataProvider } from './context/DataContext'

function GlobalHooks() {
    usePollBlockNumber()
    useEagerConnect()
    return null
}


export default function App() {
    const theme = createTheme({
        typography: {
            fontFamily: 'Square'
        },
        components: {
            MuiButton: {
                styleOverrides: {
                    root: {
                        textTransform: 'none'
                    }
                }
            }
        }
    })


    return (
        <BrowserRouter>
            <WagmiProvider client={client}>
                <Provider store={store}>
                    <LanguageProvider>
                        <SWRConfig
                            value={{
                                use: [fetchStatusMiddleware]
                            }}
                        >
                            <DataProvider>
                                <ToastsProvider>
                                    <GlobalHooks />
                                    <Updaters />
                                    <ThemeProvider theme={theme}>
                                        <ViewBase>
                                            <Routes>
                                                <Route path='/' element={<Home />} />
                                                <Route path='/home' element={<Home />} />
                                                <Route path='/swap' element={<Swap />} />
                                                <Route path='/docs' element={<Docs />} />
                                                <Route path='/farm' element={<Farm />} />
                                                <Route path='/liquidity' element={<Liquidity />} />
                                                <Route path='/add' element={<Liquidity />} />
                                                <Route path='/remove' element={<Liquidity />} />
                                                <Route path='/bridge' element={<Bridge />} />
                                            </Routes>
                                        </ViewBase>
                                        <ToastListener />
                                    </ThemeProvider>
                                </ToastsProvider>
                            </DataProvider>
                        </SWRConfig>
                    </LanguageProvider>
                </Provider>
            </WagmiProvider>
        </BrowserRouter>
    )
}
